export default {
  '#HZ001': {
    code: 0,
    data: [
      {
        id: '1',
        value: '测试订单'
      },
      {
        id: '2',
        value: '测试工单'
      },
      {
        id: '3',
        value: '测试生产单'
      }
    ]
  }
}
